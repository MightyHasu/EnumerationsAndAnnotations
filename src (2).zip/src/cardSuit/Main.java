package cardSuit;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {

    public static void main(String[] args) throws IOException {

        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
        //String cardRank = reader.readLine();
        //String cardSuit = reader.readLine();
//
        //Card firstCard = new CardIml(cardRank, cardSuit);
        //cardRank = reader.readLine();
        //cardSuit = reader.readLine();
        //Card secondCard = new CardIml(cardRank, cardSuit);
//
        //if (firstCard.compareTo(secondCard) > 0) {
        //    System.out.println(firstCard.toString());
        //}
        //System.out.println(secondCard.toString());

        Class<CardRank> cardRankClass = CardRank.class;

        Class<CardSuit> cardSuitClass = CardSuit.class;

        String in = reader.readLine();

        //switch (in) {
        //    case "Rank":
        //        CardAnotation cardAnotation = cardRankClass.getAnnotation(CardAnotation.class);
        //        System.out.println(cardAnotation.type() + ", " + cardAnotation.description());
        //        break;
        //    case "Suit":
        //        cardAnotation = cardSuitClass.getAnnotation(CardAnotation.class);
        //        System.out.println(cardAnotation.type() + ", " + cardAnotation.description());
        //        break;
        //    default:
        //        break;
        //}
        printDeck();
    }

    public static void printDeck() {
        for (CardSuit cardSuit : CardSuit.values()) {
            for (CardRank cardRank : CardRank.values()) {
                System.out.println(cardRank.name()+" of "+cardSuit.name());
            }
        }
    }

}
